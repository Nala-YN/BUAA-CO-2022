/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static int ng0[] = {15, 0};
static int ng1[] = {16, 0};
static int ng2[] = {1, 0};
static int ng3[] = {7, 0};
static int ng4[] = {8, 0};
static unsigned int ng5[] = {0U, 0U};
static unsigned int ng6[] = {1U, 0U};
static unsigned int ng7[] = {2U, 0U};
static unsigned int ng8[] = {3U, 0U};
static int ng9[] = {24, 0};
static unsigned int ng10[] = {4U, 0U};
static int ng11[] = {0, 0};
static const char *ng12 = "%d@%h: *%h <= %h";



static int sp_F_H_OUT(char *t1, char *t2)
{
    char t7[8];
    char t16[8];
    char t17[8];
    char t18[8];
    char t26[8];
    char t30[8];
    char t31[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t27;
    char *t28;
    char *t29;
    char *t32;
    char *t33;
    unsigned int t34;
    int t35;
    char *t36;
    unsigned int t37;
    int t38;
    int t39;
    char *t40;
    unsigned int t41;
    int t42;
    int t43;
    unsigned int t44;
    int t45;
    unsigned int t46;
    unsigned int t47;
    int t48;
    int t49;

LAB0:    t0 = 1;

LAB2:    t3 = (t1 + 4072);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t1 + 3752);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 32);
    t3 = (t1 + 3912);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    memset(t7, 0, 8);
    t6 = (t7 + 4);
    t8 = (t5 + 4);
    t9 = *((unsigned int *)t5);
    t10 = (t9 >> 0);
    *((unsigned int *)t7) = t10;
    t11 = *((unsigned int *)t8);
    t12 = (t11 >> 0);
    *((unsigned int *)t6) = t12;
    t13 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t13 & 65535U);
    t14 = *((unsigned int *)t6);
    *((unsigned int *)t6) = (t14 & 65535U);
    t15 = (t1 + 3752);
    t19 = (t1 + 3752);
    t20 = (t19 + 72U);
    t21 = *((char **)t20);
    t22 = ((char*)((ng0)));
    t23 = ((char*)((ng1)));
    t24 = (t1 + 2712U);
    t25 = *((char **)t24);
    t24 = (t1 + 2672U);
    t27 = (t24 + 72U);
    t28 = *((char **)t27);
    t29 = ((char*)((ng2)));
    xsi_vlog_generic_get_index_select_value(t26, 32, t25, t28, 2, t29, 32, 1);
    memset(t30, 0, 8);
    xsi_vlog_unsigned_multiply(t30, 32, t23, 32, t26, 32);
    memset(t31, 0, 8);
    xsi_vlog_unsigned_add(t31, 32, t22, 32, t30, 32);
    t32 = ((char*)((ng1)));
    xsi_vlog_convert_indexed_partindices(t16, t17, t18, ((int*)(t21)), 2, t31, 32, 2, t32, 32, 1, 0);
    t33 = (t16 + 4);
    t34 = *((unsigned int *)t33);
    t35 = (!(t34));
    t36 = (t17 + 4);
    t37 = *((unsigned int *)t36);
    t38 = (!(t37));
    t39 = (t35 && t38);
    t40 = (t18 + 4);
    t41 = *((unsigned int *)t40);
    t42 = (!(t41));
    t43 = (t39 && t42);
    if (t43 == 1)
        goto LAB3;

LAB4:    t0 = 0;

LAB1:    return t0;
LAB3:    t44 = *((unsigned int *)t18);
    t45 = (t44 + 0);
    t46 = *((unsigned int *)t16);
    t47 = *((unsigned int *)t17);
    t48 = (t46 - t47);
    t49 = (t48 + 1);
    xsi_vlogvar_assign_value(t15, t7, t45, *((unsigned int *)t17), t49);
    goto LAB4;

}

static int sp_F_B_OUT(char *t1, char *t2)
{
    char t7[8];
    char t16[8];
    char t17[8];
    char t18[8];
    char t24[8];
    char t34[8];
    char t35[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t25;
    char *t26;
    char *t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    char *t36;
    char *t37;
    unsigned int t38;
    int t39;
    char *t40;
    unsigned int t41;
    int t42;
    int t43;
    char *t44;
    unsigned int t45;
    int t46;
    int t47;
    unsigned int t48;
    int t49;
    unsigned int t50;
    unsigned int t51;
    int t52;
    int t53;

LAB0:    t0 = 1;

LAB2:    t3 = (t1 + 4552);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t1 + 4232);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 32);
    t3 = (t1 + 4392);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    memset(t7, 0, 8);
    t6 = (t7 + 4);
    t8 = (t5 + 4);
    t9 = *((unsigned int *)t5);
    t10 = (t9 >> 0);
    *((unsigned int *)t7) = t10;
    t11 = *((unsigned int *)t8);
    t12 = (t11 >> 0);
    *((unsigned int *)t6) = t12;
    t13 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t13 & 255U);
    t14 = *((unsigned int *)t6);
    *((unsigned int *)t6) = (t14 & 255U);
    t15 = (t1 + 4232);
    t19 = (t1 + 4232);
    t20 = (t19 + 72U);
    t21 = *((char **)t20);
    t22 = ((char*)((ng3)));
    t23 = ((char*)((ng4)));
    t25 = (t1 + 2712U);
    t26 = *((char **)t25);
    memset(t24, 0, 8);
    t25 = (t24 + 4);
    t27 = (t26 + 4);
    t28 = *((unsigned int *)t26);
    t29 = (t28 >> 0);
    *((unsigned int *)t24) = t29;
    t30 = *((unsigned int *)t27);
    t31 = (t30 >> 0);
    *((unsigned int *)t25) = t31;
    t32 = *((unsigned int *)t24);
    *((unsigned int *)t24) = (t32 & 3U);
    t33 = *((unsigned int *)t25);
    *((unsigned int *)t25) = (t33 & 3U);
    memset(t34, 0, 8);
    xsi_vlog_unsigned_multiply(t34, 32, t23, 32, t24, 32);
    memset(t35, 0, 8);
    xsi_vlog_unsigned_add(t35, 32, t22, 32, t34, 32);
    t36 = ((char*)((ng4)));
    xsi_vlog_convert_indexed_partindices(t16, t17, t18, ((int*)(t21)), 2, t35, 32, 2, t36, 32, 1, 0);
    t37 = (t16 + 4);
    t38 = *((unsigned int *)t37);
    t39 = (!(t38));
    t40 = (t17 + 4);
    t41 = *((unsigned int *)t40);
    t42 = (!(t41));
    t43 = (t39 && t42);
    t44 = (t18 + 4);
    t45 = *((unsigned int *)t44);
    t46 = (!(t45));
    t47 = (t43 && t46);
    if (t47 == 1)
        goto LAB3;

LAB4:    t0 = 0;

LAB1:    return t0;
LAB3:    t48 = *((unsigned int *)t18);
    t49 = (t48 + 0);
    t50 = *((unsigned int *)t16);
    t51 = *((unsigned int *)t17);
    t52 = (t50 - t51);
    t53 = (t52 + 1);
    xsi_vlogvar_assign_value(t15, t7, t49, *((unsigned int *)t17), t53);
    goto LAB4;

}

static void Cont_25_0(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[8];
    char t36[8];
    char t43[8];
    char t57[8];
    char t58[8];
    char t61[8];
    char t88[8];
    char t92[8];
    char t99[8];
    char t109[8];
    char t117[8];
    char t121[8];
    char t122[8];
    char t124[8];
    char t129[8];
    char t136[8];
    char t146[8];
    char t154[8];
    char t158[8];
    char t159[8];
    char t165[8];
    char t166[8];
    char t169[8];
    char t196[8];
    char t200[8];
    char t207[8];
    char t217[8];
    char t225[8];
    char t229[8];
    char t230[8];
    char t237[8];
    char t238[8];
    char t241[8];
    char t268[8];
    char t272[8];
    char t279[8];
    char t289[8];
    char t295[8];
    char t305[8];
    char t306[8];
    char t308[8];
    char t313[8];
    char t320[8];
    char t330[8];
    char t336[8];
    char t346[8];
    char t347[8];
    char t353[8];
    char t354[8];
    char t357[8];
    char t384[8];
    char t388[8];
    char t395[8];
    char t405[8];
    char t411[8];
    char t421[8];
    char t422[8];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    char *t34;
    char *t35;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t44;
    char *t45;
    char *t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    char *t59;
    char *t60;
    char *t62;
    char *t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    char *t76;
    char *t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    char *t83;
    char *t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    char *t89;
    char *t90;
    char *t91;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    char *t97;
    char *t98;
    char *t100;
    char *t101;
    char *t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    unsigned int t108;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    char *t114;
    char *t115;
    char *t116;
    char *t118;
    char *t119;
    char *t120;
    char *t123;
    char *t125;
    char *t126;
    char *t127;
    char *t128;
    char *t130;
    char *t131;
    char *t132;
    char *t133;
    char *t134;
    char *t135;
    char *t137;
    char *t138;
    char *t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t143;
    unsigned int t144;
    unsigned int t145;
    char *t147;
    char *t148;
    char *t149;
    char *t150;
    char *t151;
    char *t152;
    char *t153;
    char *t155;
    char *t156;
    char *t157;
    char *t160;
    unsigned int t161;
    unsigned int t162;
    unsigned int t163;
    unsigned int t164;
    char *t167;
    char *t168;
    char *t170;
    char *t171;
    unsigned int t172;
    unsigned int t173;
    unsigned int t174;
    unsigned int t175;
    unsigned int t176;
    unsigned int t177;
    unsigned int t178;
    unsigned int t179;
    unsigned int t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    char *t184;
    char *t185;
    unsigned int t186;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    unsigned int t190;
    char *t191;
    char *t192;
    unsigned int t193;
    unsigned int t194;
    unsigned int t195;
    char *t197;
    char *t198;
    char *t199;
    char *t201;
    char *t202;
    char *t203;
    char *t204;
    char *t205;
    char *t206;
    char *t208;
    char *t209;
    char *t210;
    unsigned int t211;
    unsigned int t212;
    unsigned int t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    char *t218;
    char *t219;
    char *t220;
    char *t221;
    char *t222;
    char *t223;
    char *t224;
    char *t226;
    char *t227;
    char *t228;
    char *t231;
    char *t232;
    unsigned int t233;
    unsigned int t234;
    unsigned int t235;
    unsigned int t236;
    char *t239;
    char *t240;
    char *t242;
    char *t243;
    unsigned int t244;
    unsigned int t245;
    unsigned int t246;
    unsigned int t247;
    unsigned int t248;
    unsigned int t249;
    unsigned int t250;
    unsigned int t251;
    unsigned int t252;
    unsigned int t253;
    unsigned int t254;
    unsigned int t255;
    char *t256;
    char *t257;
    unsigned int t258;
    unsigned int t259;
    unsigned int t260;
    unsigned int t261;
    unsigned int t262;
    char *t263;
    char *t264;
    unsigned int t265;
    unsigned int t266;
    unsigned int t267;
    char *t269;
    char *t270;
    char *t271;
    char *t273;
    char *t274;
    char *t275;
    char *t276;
    char *t277;
    char *t278;
    char *t280;
    char *t281;
    char *t282;
    unsigned int t283;
    unsigned int t284;
    unsigned int t285;
    unsigned int t286;
    unsigned int t287;
    unsigned int t288;
    char *t290;
    char *t291;
    char *t292;
    char *t293;
    char *t294;
    char *t296;
    char *t297;
    char *t298;
    unsigned int t299;
    unsigned int t300;
    unsigned int t301;
    unsigned int t302;
    unsigned int t303;
    unsigned int t304;
    char *t307;
    char *t309;
    char *t310;
    char *t311;
    char *t312;
    char *t314;
    char *t315;
    char *t316;
    char *t317;
    char *t318;
    char *t319;
    char *t321;
    char *t322;
    char *t323;
    unsigned int t324;
    unsigned int t325;
    unsigned int t326;
    unsigned int t327;
    unsigned int t328;
    unsigned int t329;
    char *t331;
    char *t332;
    char *t333;
    char *t334;
    char *t335;
    char *t337;
    char *t338;
    char *t339;
    unsigned int t340;
    unsigned int t341;
    unsigned int t342;
    unsigned int t343;
    unsigned int t344;
    unsigned int t345;
    char *t348;
    unsigned int t349;
    unsigned int t350;
    unsigned int t351;
    unsigned int t352;
    char *t355;
    char *t356;
    char *t358;
    char *t359;
    unsigned int t360;
    unsigned int t361;
    unsigned int t362;
    unsigned int t363;
    unsigned int t364;
    unsigned int t365;
    unsigned int t366;
    unsigned int t367;
    unsigned int t368;
    unsigned int t369;
    unsigned int t370;
    unsigned int t371;
    char *t372;
    char *t373;
    unsigned int t374;
    unsigned int t375;
    unsigned int t376;
    unsigned int t377;
    unsigned int t378;
    char *t379;
    char *t380;
    unsigned int t381;
    unsigned int t382;
    unsigned int t383;
    char *t385;
    char *t386;
    char *t387;
    char *t389;
    char *t390;
    char *t391;
    char *t392;
    char *t393;
    char *t394;
    char *t396;
    char *t397;
    char *t398;
    unsigned int t399;
    unsigned int t400;
    unsigned int t401;
    unsigned int t402;
    unsigned int t403;
    unsigned int t404;
    char *t406;
    char *t407;
    char *t408;
    char *t409;
    char *t410;
    char *t412;
    char *t413;
    char *t414;
    unsigned int t415;
    unsigned int t416;
    unsigned int t417;
    unsigned int t418;
    unsigned int t419;
    unsigned int t420;
    char *t423;
    char *t424;
    unsigned int t425;
    unsigned int t426;
    unsigned int t427;
    unsigned int t428;
    char *t429;
    char *t430;
    char *t431;
    char *t432;
    char *t433;
    char *t434;
    char *t435;

LAB0:    t1 = (t0 + 5472U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 2552U);
    t5 = *((char **)t2);
    t2 = ((char*)((ng5)));
    memset(t6, 0, 8);
    t7 = (t5 + 4);
    t8 = (t2 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t2);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t6) = 1;

LAB7:    memset(t4, 0, 8);
    t22 = (t6 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t6);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t22) != 0)
        goto LAB10;

LAB11:    t29 = (t4 + 4);
    t30 = *((unsigned int *)t4);
    t31 = *((unsigned int *)t29);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB12;

LAB13:    t53 = *((unsigned int *)t4);
    t54 = (~(t53));
    t55 = *((unsigned int *)t29);
    t56 = (t54 || t55);
    if (t56 > 0)
        goto LAB14;

LAB15:    if (*((unsigned int *)t29) > 0)
        goto LAB16;

LAB17:    if (*((unsigned int *)t4) > 0)
        goto LAB18;

LAB19:    memcpy(t3, t57, 8);

LAB20:    t430 = (t0 + 6384);
    t431 = (t430 + 56U);
    t432 = *((char **)t431);
    t433 = (t432 + 56U);
    t434 = *((char **)t433);
    memcpy(t434, t3, 8);
    xsi_driver_vfirst_trans(t430, 0, 31);
    t435 = (t0 + 6288);
    *((int *)t435) = 1;

LAB1:    return;
LAB6:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t4) = 1;
    goto LAB11;

LAB10:    t28 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB11;

LAB12:    t33 = (t0 + 3432);
    t34 = (t33 + 56U);
    t35 = *((char **)t34);
    t37 = (t0 + 3432);
    t38 = (t37 + 72U);
    t39 = *((char **)t38);
    t40 = (t0 + 3432);
    t41 = (t40 + 64U);
    t42 = *((char **)t41);
    t44 = (t0 + 2712U);
    t45 = *((char **)t44);
    memset(t43, 0, 8);
    t44 = (t43 + 4);
    t46 = (t45 + 4);
    t47 = *((unsigned int *)t45);
    t48 = (t47 >> 2);
    *((unsigned int *)t43) = t48;
    t49 = *((unsigned int *)t46);
    t50 = (t49 >> 2);
    *((unsigned int *)t44) = t50;
    t51 = *((unsigned int *)t43);
    *((unsigned int *)t43) = (t51 & 16383U);
    t52 = *((unsigned int *)t44);
    *((unsigned int *)t44) = (t52 & 16383U);
    xsi_vlog_generic_get_array_select_value(t36, 32, t35, t39, t42, 2, 1, t43, 14, 2);
    goto LAB13;

LAB14:    t59 = (t0 + 2552U);
    t60 = *((char **)t59);
    t59 = ((char*)((ng6)));
    memset(t61, 0, 8);
    t62 = (t60 + 4);
    t63 = (t59 + 4);
    t64 = *((unsigned int *)t60);
    t65 = *((unsigned int *)t59);
    t66 = (t64 ^ t65);
    t67 = *((unsigned int *)t62);
    t68 = *((unsigned int *)t63);
    t69 = (t67 ^ t68);
    t70 = (t66 | t69);
    t71 = *((unsigned int *)t62);
    t72 = *((unsigned int *)t63);
    t73 = (t71 | t72);
    t74 = (~(t73));
    t75 = (t70 & t74);
    if (t75 != 0)
        goto LAB24;

LAB21:    if (t73 != 0)
        goto LAB23;

LAB22:    *((unsigned int *)t61) = 1;

LAB24:    memset(t58, 0, 8);
    t77 = (t61 + 4);
    t78 = *((unsigned int *)t77);
    t79 = (~(t78));
    t80 = *((unsigned int *)t61);
    t81 = (t80 & t79);
    t82 = (t81 & 1U);
    if (t82 != 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t77) != 0)
        goto LAB27;

LAB28:    t84 = (t58 + 4);
    t85 = *((unsigned int *)t58);
    t86 = *((unsigned int *)t84);
    t87 = (t85 || t86);
    if (t87 > 0)
        goto LAB29;

LAB30:    t161 = *((unsigned int *)t58);
    t162 = (~(t161));
    t163 = *((unsigned int *)t84);
    t164 = (t162 || t163);
    if (t164 > 0)
        goto LAB31;

LAB32:    if (*((unsigned int *)t84) > 0)
        goto LAB33;

LAB34:    if (*((unsigned int *)t58) > 0)
        goto LAB35;

LAB36:    memcpy(t57, t165, 8);

LAB37:    goto LAB15;

LAB16:    xsi_vlog_unsigned_bit_combine(t3, 32, t36, 32, t57, 32);
    goto LAB20;

LAB18:    memcpy(t3, t36, 8);
    goto LAB20;

LAB23:    t76 = (t61 + 4);
    *((unsigned int *)t61) = 1;
    *((unsigned int *)t76) = 1;
    goto LAB24;

LAB25:    *((unsigned int *)t58) = 1;
    goto LAB28;

LAB27:    t83 = (t58 + 4);
    *((unsigned int *)t58) = 1;
    *((unsigned int *)t83) = 1;
    goto LAB28;

LAB29:    t89 = (t0 + 3432);
    t90 = (t89 + 56U);
    t91 = *((char **)t90);
    t93 = (t0 + 3432);
    t94 = (t93 + 72U);
    t95 = *((char **)t94);
    t96 = (t0 + 3432);
    t97 = (t96 + 64U);
    t98 = *((char **)t97);
    t100 = (t0 + 2712U);
    t101 = *((char **)t100);
    memset(t99, 0, 8);
    t100 = (t99 + 4);
    t102 = (t101 + 4);
    t103 = *((unsigned int *)t101);
    t104 = (t103 >> 2);
    *((unsigned int *)t99) = t104;
    t105 = *((unsigned int *)t102);
    t106 = (t105 >> 2);
    *((unsigned int *)t100) = t106;
    t107 = *((unsigned int *)t99);
    *((unsigned int *)t99) = (t107 & 16383U);
    t108 = *((unsigned int *)t100);
    *((unsigned int *)t100) = (t108 & 16383U);
    xsi_vlog_generic_get_array_select_value(t92, 32, t91, t95, t98, 2, 1, t99, 14, 2);
    t110 = (t0 + 3432);
    t111 = (t110 + 72U);
    t112 = *((char **)t111);
    t113 = ((char*)((ng0)));
    t114 = ((char*)((ng1)));
    t115 = (t0 + 2712U);
    t116 = *((char **)t115);
    t115 = (t0 + 2672U);
    t118 = (t115 + 72U);
    t119 = *((char **)t118);
    t120 = ((char*)((ng2)));
    xsi_vlog_generic_get_index_select_value(t117, 32, t116, t119, 2, t120, 32, 1);
    memset(t121, 0, 8);
    xsi_vlog_unsigned_multiply(t121, 32, t114, 32, t117, 32);
    memset(t122, 0, 8);
    xsi_vlog_unsigned_add(t122, 32, t113, 32, t121, 32);
    t123 = ((char*)((ng1)));
    xsi_vlog_get_indexed_partselect(t109, 16, t92, ((int*)(t112)), 2, t122, 32, 2, t123, 32, 1, 0);
    t125 = ((char*)((ng1)));
    t126 = (t0 + 3432);
    t127 = (t126 + 56U);
    t128 = *((char **)t127);
    t130 = (t0 + 3432);
    t131 = (t130 + 72U);
    t132 = *((char **)t131);
    t133 = (t0 + 3432);
    t134 = (t133 + 64U);
    t135 = *((char **)t134);
    t137 = (t0 + 2712U);
    t138 = *((char **)t137);
    memset(t136, 0, 8);
    t137 = (t136 + 4);
    t139 = (t138 + 4);
    t140 = *((unsigned int *)t138);
    t141 = (t140 >> 2);
    *((unsigned int *)t136) = t141;
    t142 = *((unsigned int *)t139);
    t143 = (t142 >> 2);
    *((unsigned int *)t137) = t143;
    t144 = *((unsigned int *)t136);
    *((unsigned int *)t136) = (t144 & 16383U);
    t145 = *((unsigned int *)t137);
    *((unsigned int *)t137) = (t145 & 16383U);
    xsi_vlog_generic_get_array_select_value(t129, 32, t128, t132, t135, 2, 1, t136, 14, 2);
    t147 = (t0 + 3432);
    t148 = (t147 + 72U);
    t149 = *((char **)t148);
    t150 = ((char*)((ng0)));
    t151 = ((char*)((ng1)));
    t152 = (t0 + 2712U);
    t153 = *((char **)t152);
    t152 = (t0 + 2672U);
    t155 = (t152 + 72U);
    t156 = *((char **)t155);
    t157 = ((char*)((ng2)));
    xsi_vlog_generic_get_index_select_value(t154, 32, t153, t156, 2, t157, 32, 1);
    memset(t158, 0, 8);
    xsi_vlog_unsigned_multiply(t158, 32, t151, 32, t154, 32);
    memset(t159, 0, 8);
    xsi_vlog_unsigned_add(t159, 32, t150, 32, t158, 32);
    t160 = ((char*)((ng2)));
    xsi_vlog_get_indexed_partselect(t146, 1, t129, ((int*)(t149)), 2, t159, 32, 2, t160, 32, 1, 0);
    xsi_vlog_mul_concat(t124, 16, 1, t125, 1U, t146, 1);
    xsi_vlogtype_concat(t88, 32, 32, 2U, t124, 16, t109, 16);
    goto LAB30;

LAB31:    t167 = (t0 + 2552U);
    t168 = *((char **)t167);
    t167 = ((char*)((ng7)));
    memset(t169, 0, 8);
    t170 = (t168 + 4);
    t171 = (t167 + 4);
    t172 = *((unsigned int *)t168);
    t173 = *((unsigned int *)t167);
    t174 = (t172 ^ t173);
    t175 = *((unsigned int *)t170);
    t176 = *((unsigned int *)t171);
    t177 = (t175 ^ t176);
    t178 = (t174 | t177);
    t179 = *((unsigned int *)t170);
    t180 = *((unsigned int *)t171);
    t181 = (t179 | t180);
    t182 = (~(t181));
    t183 = (t178 & t182);
    if (t183 != 0)
        goto LAB41;

LAB38:    if (t181 != 0)
        goto LAB40;

LAB39:    *((unsigned int *)t169) = 1;

LAB41:    memset(t166, 0, 8);
    t185 = (t169 + 4);
    t186 = *((unsigned int *)t185);
    t187 = (~(t186));
    t188 = *((unsigned int *)t169);
    t189 = (t188 & t187);
    t190 = (t189 & 1U);
    if (t190 != 0)
        goto LAB42;

LAB43:    if (*((unsigned int *)t185) != 0)
        goto LAB44;

LAB45:    t192 = (t166 + 4);
    t193 = *((unsigned int *)t166);
    t194 = *((unsigned int *)t192);
    t195 = (t193 || t194);
    if (t195 > 0)
        goto LAB46;

LAB47:    t233 = *((unsigned int *)t166);
    t234 = (~(t233));
    t235 = *((unsigned int *)t192);
    t236 = (t234 || t235);
    if (t236 > 0)
        goto LAB48;

LAB49:    if (*((unsigned int *)t192) > 0)
        goto LAB50;

LAB51:    if (*((unsigned int *)t166) > 0)
        goto LAB52;

LAB53:    memcpy(t165, t237, 8);

LAB54:    goto LAB32;

LAB33:    xsi_vlog_unsigned_bit_combine(t57, 32, t88, 32, t165, 32);
    goto LAB37;

LAB35:    memcpy(t57, t88, 8);
    goto LAB37;

LAB40:    t184 = (t169 + 4);
    *((unsigned int *)t169) = 1;
    *((unsigned int *)t184) = 1;
    goto LAB41;

LAB42:    *((unsigned int *)t166) = 1;
    goto LAB45;

LAB44:    t191 = (t166 + 4);
    *((unsigned int *)t166) = 1;
    *((unsigned int *)t191) = 1;
    goto LAB45;

LAB46:    t197 = (t0 + 3432);
    t198 = (t197 + 56U);
    t199 = *((char **)t198);
    t201 = (t0 + 3432);
    t202 = (t201 + 72U);
    t203 = *((char **)t202);
    t204 = (t0 + 3432);
    t205 = (t204 + 64U);
    t206 = *((char **)t205);
    t208 = (t0 + 2712U);
    t209 = *((char **)t208);
    memset(t207, 0, 8);
    t208 = (t207 + 4);
    t210 = (t209 + 4);
    t211 = *((unsigned int *)t209);
    t212 = (t211 >> 2);
    *((unsigned int *)t207) = t212;
    t213 = *((unsigned int *)t210);
    t214 = (t213 >> 2);
    *((unsigned int *)t208) = t214;
    t215 = *((unsigned int *)t207);
    *((unsigned int *)t207) = (t215 & 16383U);
    t216 = *((unsigned int *)t208);
    *((unsigned int *)t208) = (t216 & 16383U);
    xsi_vlog_generic_get_array_select_value(t200, 32, t199, t203, t206, 2, 1, t207, 14, 2);
    t218 = (t0 + 3432);
    t219 = (t218 + 72U);
    t220 = *((char **)t219);
    t221 = ((char*)((ng0)));
    t222 = ((char*)((ng1)));
    t223 = (t0 + 2712U);
    t224 = *((char **)t223);
    t223 = (t0 + 2672U);
    t226 = (t223 + 72U);
    t227 = *((char **)t226);
    t228 = ((char*)((ng2)));
    xsi_vlog_generic_get_index_select_value(t225, 32, t224, t227, 2, t228, 32, 1);
    memset(t229, 0, 8);
    xsi_vlog_unsigned_multiply(t229, 32, t222, 32, t225, 32);
    memset(t230, 0, 8);
    xsi_vlog_unsigned_add(t230, 32, t221, 32, t229, 32);
    t231 = ((char*)((ng1)));
    xsi_vlog_get_indexed_partselect(t217, 16, t200, ((int*)(t220)), 2, t230, 32, 2, t231, 32, 1, 0);
    t232 = ((char*)((ng5)));
    xsi_vlogtype_concat(t196, 32, 32, 2U, t232, 16, t217, 16);
    goto LAB47;

LAB48:    t239 = (t0 + 2552U);
    t240 = *((char **)t239);
    t239 = ((char*)((ng8)));
    memset(t241, 0, 8);
    t242 = (t240 + 4);
    t243 = (t239 + 4);
    t244 = *((unsigned int *)t240);
    t245 = *((unsigned int *)t239);
    t246 = (t244 ^ t245);
    t247 = *((unsigned int *)t242);
    t248 = *((unsigned int *)t243);
    t249 = (t247 ^ t248);
    t250 = (t246 | t249);
    t251 = *((unsigned int *)t242);
    t252 = *((unsigned int *)t243);
    t253 = (t251 | t252);
    t254 = (~(t253));
    t255 = (t250 & t254);
    if (t255 != 0)
        goto LAB58;

LAB55:    if (t253 != 0)
        goto LAB57;

LAB56:    *((unsigned int *)t241) = 1;

LAB58:    memset(t238, 0, 8);
    t257 = (t241 + 4);
    t258 = *((unsigned int *)t257);
    t259 = (~(t258));
    t260 = *((unsigned int *)t241);
    t261 = (t260 & t259);
    t262 = (t261 & 1U);
    if (t262 != 0)
        goto LAB59;

LAB60:    if (*((unsigned int *)t257) != 0)
        goto LAB61;

LAB62:    t264 = (t238 + 4);
    t265 = *((unsigned int *)t238);
    t266 = *((unsigned int *)t264);
    t267 = (t265 || t266);
    if (t267 > 0)
        goto LAB63;

LAB64:    t349 = *((unsigned int *)t238);
    t350 = (~(t349));
    t351 = *((unsigned int *)t264);
    t352 = (t350 || t351);
    if (t352 > 0)
        goto LAB65;

LAB66:    if (*((unsigned int *)t264) > 0)
        goto LAB67;

LAB68:    if (*((unsigned int *)t238) > 0)
        goto LAB69;

LAB70:    memcpy(t237, t353, 8);

LAB71:    goto LAB49;

LAB50:    xsi_vlog_unsigned_bit_combine(t165, 32, t196, 32, t237, 32);
    goto LAB54;

LAB52:    memcpy(t165, t196, 8);
    goto LAB54;

LAB57:    t256 = (t241 + 4);
    *((unsigned int *)t241) = 1;
    *((unsigned int *)t256) = 1;
    goto LAB58;

LAB59:    *((unsigned int *)t238) = 1;
    goto LAB62;

LAB61:    t263 = (t238 + 4);
    *((unsigned int *)t238) = 1;
    *((unsigned int *)t263) = 1;
    goto LAB62;

LAB63:    t269 = (t0 + 3432);
    t270 = (t269 + 56U);
    t271 = *((char **)t270);
    t273 = (t0 + 3432);
    t274 = (t273 + 72U);
    t275 = *((char **)t274);
    t276 = (t0 + 3432);
    t277 = (t276 + 64U);
    t278 = *((char **)t277);
    t280 = (t0 + 2712U);
    t281 = *((char **)t280);
    memset(t279, 0, 8);
    t280 = (t279 + 4);
    t282 = (t281 + 4);
    t283 = *((unsigned int *)t281);
    t284 = (t283 >> 2);
    *((unsigned int *)t279) = t284;
    t285 = *((unsigned int *)t282);
    t286 = (t285 >> 2);
    *((unsigned int *)t280) = t286;
    t287 = *((unsigned int *)t279);
    *((unsigned int *)t279) = (t287 & 16383U);
    t288 = *((unsigned int *)t280);
    *((unsigned int *)t280) = (t288 & 16383U);
    xsi_vlog_generic_get_array_select_value(t272, 32, t271, t275, t278, 2, 1, t279, 14, 2);
    t290 = (t0 + 3432);
    t291 = (t290 + 72U);
    t292 = *((char **)t291);
    t293 = ((char*)((ng3)));
    t294 = ((char*)((ng4)));
    t296 = (t0 + 2712U);
    t297 = *((char **)t296);
    memset(t295, 0, 8);
    t296 = (t295 + 4);
    t298 = (t297 + 4);
    t299 = *((unsigned int *)t297);
    t300 = (t299 >> 0);
    *((unsigned int *)t295) = t300;
    t301 = *((unsigned int *)t298);
    t302 = (t301 >> 0);
    *((unsigned int *)t296) = t302;
    t303 = *((unsigned int *)t295);
    *((unsigned int *)t295) = (t303 & 3U);
    t304 = *((unsigned int *)t296);
    *((unsigned int *)t296) = (t304 & 3U);
    memset(t305, 0, 8);
    xsi_vlog_unsigned_multiply(t305, 32, t294, 32, t295, 32);
    memset(t306, 0, 8);
    xsi_vlog_unsigned_add(t306, 32, t293, 32, t305, 32);
    t307 = ((char*)((ng4)));
    xsi_vlog_get_indexed_partselect(t289, 8, t272, ((int*)(t292)), 2, t306, 32, 2, t307, 32, 1, 0);
    t309 = ((char*)((ng9)));
    t310 = (t0 + 3432);
    t311 = (t310 + 56U);
    t312 = *((char **)t311);
    t314 = (t0 + 3432);
    t315 = (t314 + 72U);
    t316 = *((char **)t315);
    t317 = (t0 + 3432);
    t318 = (t317 + 64U);
    t319 = *((char **)t318);
    t321 = (t0 + 2712U);
    t322 = *((char **)t321);
    memset(t320, 0, 8);
    t321 = (t320 + 4);
    t323 = (t322 + 4);
    t324 = *((unsigned int *)t322);
    t325 = (t324 >> 2);
    *((unsigned int *)t320) = t325;
    t326 = *((unsigned int *)t323);
    t327 = (t326 >> 2);
    *((unsigned int *)t321) = t327;
    t328 = *((unsigned int *)t320);
    *((unsigned int *)t320) = (t328 & 16383U);
    t329 = *((unsigned int *)t321);
    *((unsigned int *)t321) = (t329 & 16383U);
    xsi_vlog_generic_get_array_select_value(t313, 32, t312, t316, t319, 2, 1, t320, 14, 2);
    t331 = (t0 + 3432);
    t332 = (t331 + 72U);
    t333 = *((char **)t332);
    t334 = ((char*)((ng3)));
    t335 = ((char*)((ng4)));
    t337 = (t0 + 2712U);
    t338 = *((char **)t337);
    memset(t336, 0, 8);
    t337 = (t336 + 4);
    t339 = (t338 + 4);
    t340 = *((unsigned int *)t338);
    t341 = (t340 >> 0);
    *((unsigned int *)t336) = t341;
    t342 = *((unsigned int *)t339);
    t343 = (t342 >> 0);
    *((unsigned int *)t337) = t343;
    t344 = *((unsigned int *)t336);
    *((unsigned int *)t336) = (t344 & 3U);
    t345 = *((unsigned int *)t337);
    *((unsigned int *)t337) = (t345 & 3U);
    memset(t346, 0, 8);
    xsi_vlog_unsigned_multiply(t346, 32, t335, 32, t336, 32);
    memset(t347, 0, 8);
    xsi_vlog_unsigned_add(t347, 32, t334, 32, t346, 32);
    t348 = ((char*)((ng2)));
    xsi_vlog_get_indexed_partselect(t330, 1, t313, ((int*)(t333)), 2, t347, 32, 2, t348, 32, 1, 0);
    xsi_vlog_mul_concat(t308, 24, 1, t309, 1U, t330, 1);
    xsi_vlogtype_concat(t268, 32, 32, 2U, t308, 24, t289, 8);
    goto LAB64;

LAB65:    t355 = (t0 + 2552U);
    t356 = *((char **)t355);
    t355 = ((char*)((ng10)));
    memset(t357, 0, 8);
    t358 = (t356 + 4);
    t359 = (t355 + 4);
    t360 = *((unsigned int *)t356);
    t361 = *((unsigned int *)t355);
    t362 = (t360 ^ t361);
    t363 = *((unsigned int *)t358);
    t364 = *((unsigned int *)t359);
    t365 = (t363 ^ t364);
    t366 = (t362 | t365);
    t367 = *((unsigned int *)t358);
    t368 = *((unsigned int *)t359);
    t369 = (t367 | t368);
    t370 = (~(t369));
    t371 = (t366 & t370);
    if (t371 != 0)
        goto LAB75;

LAB72:    if (t369 != 0)
        goto LAB74;

LAB73:    *((unsigned int *)t357) = 1;

LAB75:    memset(t354, 0, 8);
    t373 = (t357 + 4);
    t374 = *((unsigned int *)t373);
    t375 = (~(t374));
    t376 = *((unsigned int *)t357);
    t377 = (t376 & t375);
    t378 = (t377 & 1U);
    if (t378 != 0)
        goto LAB76;

LAB77:    if (*((unsigned int *)t373) != 0)
        goto LAB78;

LAB79:    t380 = (t354 + 4);
    t381 = *((unsigned int *)t354);
    t382 = *((unsigned int *)t380);
    t383 = (t381 || t382);
    if (t383 > 0)
        goto LAB80;

LAB81:    t425 = *((unsigned int *)t354);
    t426 = (~(t425));
    t427 = *((unsigned int *)t380);
    t428 = (t426 || t427);
    if (t428 > 0)
        goto LAB82;

LAB83:    if (*((unsigned int *)t380) > 0)
        goto LAB84;

LAB85:    if (*((unsigned int *)t354) > 0)
        goto LAB86;

LAB87:    memcpy(t353, t429, 8);

LAB88:    goto LAB66;

LAB67:    xsi_vlog_unsigned_bit_combine(t237, 32, t268, 32, t353, 32);
    goto LAB71;

LAB69:    memcpy(t237, t268, 8);
    goto LAB71;

LAB74:    t372 = (t357 + 4);
    *((unsigned int *)t357) = 1;
    *((unsigned int *)t372) = 1;
    goto LAB75;

LAB76:    *((unsigned int *)t354) = 1;
    goto LAB79;

LAB78:    t379 = (t354 + 4);
    *((unsigned int *)t354) = 1;
    *((unsigned int *)t379) = 1;
    goto LAB79;

LAB80:    t385 = (t0 + 3432);
    t386 = (t385 + 56U);
    t387 = *((char **)t386);
    t389 = (t0 + 3432);
    t390 = (t389 + 72U);
    t391 = *((char **)t390);
    t392 = (t0 + 3432);
    t393 = (t392 + 64U);
    t394 = *((char **)t393);
    t396 = (t0 + 2712U);
    t397 = *((char **)t396);
    memset(t395, 0, 8);
    t396 = (t395 + 4);
    t398 = (t397 + 4);
    t399 = *((unsigned int *)t397);
    t400 = (t399 >> 2);
    *((unsigned int *)t395) = t400;
    t401 = *((unsigned int *)t398);
    t402 = (t401 >> 2);
    *((unsigned int *)t396) = t402;
    t403 = *((unsigned int *)t395);
    *((unsigned int *)t395) = (t403 & 16383U);
    t404 = *((unsigned int *)t396);
    *((unsigned int *)t396) = (t404 & 16383U);
    xsi_vlog_generic_get_array_select_value(t388, 32, t387, t391, t394, 2, 1, t395, 14, 2);
    t406 = (t0 + 3432);
    t407 = (t406 + 72U);
    t408 = *((char **)t407);
    t409 = ((char*)((ng3)));
    t410 = ((char*)((ng4)));
    t412 = (t0 + 2712U);
    t413 = *((char **)t412);
    memset(t411, 0, 8);
    t412 = (t411 + 4);
    t414 = (t413 + 4);
    t415 = *((unsigned int *)t413);
    t416 = (t415 >> 0);
    *((unsigned int *)t411) = t416;
    t417 = *((unsigned int *)t414);
    t418 = (t417 >> 0);
    *((unsigned int *)t412) = t418;
    t419 = *((unsigned int *)t411);
    *((unsigned int *)t411) = (t419 & 3U);
    t420 = *((unsigned int *)t412);
    *((unsigned int *)t412) = (t420 & 3U);
    memset(t421, 0, 8);
    xsi_vlog_unsigned_multiply(t421, 32, t410, 32, t411, 32);
    memset(t422, 0, 8);
    xsi_vlog_unsigned_add(t422, 32, t409, 32, t421, 32);
    t423 = ((char*)((ng4)));
    xsi_vlog_get_indexed_partselect(t405, 8, t388, ((int*)(t408)), 2, t422, 32, 2, t423, 32, 1, 0);
    t424 = ((char*)((ng5)));
    xsi_vlogtype_concat(t384, 32, 32, 2U, t424, 24, t405, 8);
    goto LAB81;

LAB82:    t429 = ((char*)((ng5)));
    goto LAB83;

LAB84:    xsi_vlog_unsigned_bit_combine(t353, 32, t384, 32, t429, 32);
    goto LAB88;

LAB86:    memcpy(t353, t384, 8);
    goto LAB88;

}

static void Initial_34_1(char *t0)
{
    char t6[8];
    char t7[8];
    char t16[8];
    char t17[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    char *t15;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    unsigned int t28;
    int t29;
    char *t30;
    unsigned int t31;
    int t32;
    int t33;
    unsigned int t34;
    unsigned int t35;
    int t36;
    int t37;

LAB0:
LAB2:    t1 = ((char*)((ng11)));
    t2 = (t0 + 3592);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 32);

LAB3:    t1 = (t0 + 3592);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = ((char*)((ng2)));
    t5 = ((char*)((ng0)));
    memset(t6, 0, 8);
    xsi_vlog_signed_lshift(t6, 32, t4, 32, t5, 32);
    memset(t7, 0, 8);
    xsi_vlog_signed_less(t7, 32, t3, 32, t6, 32);
    t8 = (t7 + 4);
    t9 = *((unsigned int *)t8);
    t10 = (~(t9));
    t11 = *((unsigned int *)t7);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB4;

LAB5:
LAB1:    return;
LAB4:    t14 = ((char*)((ng11)));
    t15 = (t0 + 3432);
    t18 = (t0 + 3432);
    t19 = (t18 + 72U);
    t20 = *((char **)t19);
    t21 = (t0 + 3432);
    t22 = (t21 + 64U);
    t23 = *((char **)t22);
    t24 = (t0 + 3592);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    xsi_vlog_generic_convert_array_indices(t16, t17, t20, t23, 2, 1, t26, 32, 1);
    t27 = (t16 + 4);
    t28 = *((unsigned int *)t27);
    t29 = (!(t28));
    t30 = (t17 + 4);
    t31 = *((unsigned int *)t30);
    t32 = (!(t31));
    t33 = (t29 && t32);
    if (t33 == 1)
        goto LAB6;

LAB7:    t1 = (t0 + 3592);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = ((char*)((ng2)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t3, 32, t4, 32);
    t5 = (t0 + 3592);
    xsi_vlogvar_assign_value(t5, t6, 0, 0, 32);
    goto LAB3;

LAB6:    t34 = *((unsigned int *)t16);
    t35 = *((unsigned int *)t17);
    t36 = (t34 - t35);
    t37 = (t36 + 1);
    xsi_vlogvar_wait_assign_value(t15, t14, 0, *((unsigned int *)t17), t37, 0LL);
    goto LAB7;

}

static void Always_56_2(char *t0)
{
    char t13[8];
    char t14[8];
    char t17[8];
    char t18[8];
    char t64[16];
    char t65[8];
    char t66[8];
    char t67[8];
    char t68[8];
    char t74[8];
    char t78[8];
    char t79[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t15;
    char *t16;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t29;
    int t30;
    char *t31;
    unsigned int t32;
    int t33;
    int t34;
    unsigned int t35;
    unsigned int t36;
    int t37;
    int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    char *t58;
    unsigned int t59;
    char *t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    char *t69;
    char *t70;
    char *t71;
    char *t72;
    char *t73;
    char *t75;
    char *t76;
    char *t77;
    char *t80;
    char *t81;
    char *t82;
    char *t83;
    char *t84;
    unsigned int t85;
    int t86;
    int t87;
    char *t88;
    unsigned int t89;
    int t90;
    int t91;
    unsigned int t92;
    int t93;
    unsigned int t94;
    unsigned int t95;
    int t96;
    unsigned int t97;
    unsigned int t98;
    int t99;
    int t100;
    char *t101;
    char *t102;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    char *t107;
    char *t108;
    char *t109;
    char *t110;
    char *t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;

LAB0:    t1 = (t0 + 5968U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 6304);
    *((int *)t2) = 1;
    t3 = (t0 + 6000);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:
LAB5:    t4 = (t0 + 2232U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    t2 = (t0 + 2392U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB15;

LAB16:
LAB17:
LAB8:    goto LAB2;

LAB6:
LAB9:    t11 = ((char*)((ng11)));
    t12 = (t0 + 3592);
    xsi_vlogvar_assign_value(t12, t11, 0, 0, 32);

LAB10:    t2 = (t0 + 3592);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    t11 = ((char*)((ng0)));
    memset(t13, 0, 8);
    xsi_vlog_signed_lshift(t13, 32, t5, 32, t11, 32);
    memset(t14, 0, 8);
    xsi_vlog_signed_less(t14, 32, t4, 32, t13, 32);
    t12 = (t14 + 4);
    t6 = *((unsigned int *)t12);
    t7 = (~(t6));
    t8 = *((unsigned int *)t14);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB11;

LAB12:    goto LAB8;

LAB11:    t15 = ((char*)((ng11)));
    t16 = (t0 + 3432);
    t19 = (t0 + 3432);
    t20 = (t19 + 72U);
    t21 = *((char **)t20);
    t22 = (t0 + 3432);
    t23 = (t22 + 64U);
    t24 = *((char **)t23);
    t25 = (t0 + 3592);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    xsi_vlog_generic_convert_array_indices(t17, t18, t21, t24, 2, 1, t27, 32, 1);
    t28 = (t17 + 4);
    t29 = *((unsigned int *)t28);
    t30 = (!(t29));
    t31 = (t18 + 4);
    t32 = *((unsigned int *)t31);
    t33 = (!(t32));
    t34 = (t30 && t33);
    if (t34 == 1)
        goto LAB13;

LAB14:    t2 = (t0 + 3592);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    memset(t13, 0, 8);
    xsi_vlog_signed_add(t13, 32, t4, 32, t5, 32);
    t11 = (t0 + 3592);
    xsi_vlogvar_assign_value(t11, t13, 0, 0, 32);
    goto LAB10;

LAB13:    t35 = *((unsigned int *)t17);
    t36 = *((unsigned int *)t18);
    t37 = (t35 - t36);
    t38 = (t37 + 1);
    xsi_vlogvar_wait_assign_value(t16, t15, 0, *((unsigned int *)t18), t38, 0LL);
    goto LAB14;

LAB15:
LAB18:    t4 = (t0 + 2552U);
    t5 = *((char **)t4);
    t4 = ((char*)((ng5)));
    memset(t13, 0, 8);
    t11 = (t5 + 4);
    t12 = (t4 + 4);
    t29 = *((unsigned int *)t5);
    t32 = *((unsigned int *)t4);
    t35 = (t29 ^ t32);
    t36 = *((unsigned int *)t11);
    t39 = *((unsigned int *)t12);
    t40 = (t36 ^ t39);
    t41 = (t35 | t40);
    t42 = *((unsigned int *)t11);
    t43 = *((unsigned int *)t12);
    t44 = (t42 | t43);
    t45 = (~(t44));
    t46 = (t41 & t45);
    if (t46 != 0)
        goto LAB22;

LAB19:    if (t44 != 0)
        goto LAB21;

LAB20:    *((unsigned int *)t13) = 1;

LAB22:    t16 = (t13 + 4);
    t47 = *((unsigned int *)t16);
    t48 = (~(t47));
    t49 = *((unsigned int *)t13);
    t50 = (t49 & t48);
    t51 = (t50 != 0);
    if (t51 > 0)
        goto LAB23;

LAB24:    t2 = (t0 + 2552U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng6)));
    memset(t13, 0, 8);
    t4 = (t3 + 4);
    t5 = (t2 + 4);
    t6 = *((unsigned int *)t3);
    t7 = *((unsigned int *)t2);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t29 = (t9 ^ t10);
    t32 = (t8 | t29);
    t35 = *((unsigned int *)t4);
    t36 = *((unsigned int *)t5);
    t39 = (t35 | t36);
    t40 = (~(t39));
    t41 = (t32 & t40);
    if (t41 != 0)
        goto LAB35;

LAB32:    if (t39 != 0)
        goto LAB34;

LAB33:    *((unsigned int *)t13) = 1;

LAB35:    t12 = (t13 + 4);
    t42 = *((unsigned int *)t12);
    t43 = (~(t42));
    t44 = *((unsigned int *)t13);
    t45 = (t44 & t43);
    t46 = (t45 != 0);
    if (t46 > 0)
        goto LAB36;

LAB37:    t2 = (t0 + 2552U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng8)));
    memset(t13, 0, 8);
    t4 = (t3 + 4);
    t5 = (t2 + 4);
    t6 = *((unsigned int *)t3);
    t7 = *((unsigned int *)t2);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t29 = (t9 ^ t10);
    t32 = (t8 | t29);
    t35 = *((unsigned int *)t4);
    t36 = *((unsigned int *)t5);
    t39 = (t35 | t36);
    t40 = (~(t39));
    t41 = (t32 & t40);
    if (t41 != 0)
        goto LAB51;

LAB48:    if (t39 != 0)
        goto LAB50;

LAB49:    *((unsigned int *)t13) = 1;

LAB51:    t12 = (t13 + 4);
    t42 = *((unsigned int *)t12);
    t43 = (~(t42));
    t44 = *((unsigned int *)t13);
    t45 = (t44 & t43);
    t46 = (t45 != 0);
    if (t46 > 0)
        goto LAB52;

LAB53:
LAB54:
LAB38:
LAB25:    goto LAB17;

LAB21:    t15 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t15) = 1;
    goto LAB22;

LAB23:
LAB26:    t19 = (t0 + 2872U);
    t20 = *((char **)t19);
    t19 = (t0 + 3432);
    t21 = (t0 + 3432);
    t22 = (t21 + 72U);
    t23 = *((char **)t22);
    t24 = (t0 + 3432);
    t25 = (t24 + 64U);
    t26 = *((char **)t25);
    t27 = (t0 + 2712U);
    t28 = *((char **)t27);
    memset(t18, 0, 8);
    t27 = (t18 + 4);
    t31 = (t28 + 4);
    t52 = *((unsigned int *)t28);
    t53 = (t52 >> 2);
    *((unsigned int *)t18) = t53;
    t54 = *((unsigned int *)t31);
    t55 = (t54 >> 2);
    *((unsigned int *)t27) = t55;
    t56 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t56 & 16383U);
    t57 = *((unsigned int *)t27);
    *((unsigned int *)t27) = (t57 & 16383U);
    xsi_vlog_generic_convert_array_indices(t14, t17, t23, t26, 2, 1, t18, 14, 2);
    t58 = (t14 + 4);
    t59 = *((unsigned int *)t58);
    t30 = (!(t59));
    t60 = (t17 + 4);
    t61 = *((unsigned int *)t60);
    t33 = (!(t61));
    t34 = (t30 && t33);
    if (t34 == 1)
        goto LAB27;

LAB28:    t2 = xsi_vlog_time(t64, 1000.0000000000000, 1000.0000000000000);
    t3 = (t0 + 1912U);
    t4 = *((char **)t3);
    t3 = (t0 + 2712U);
    t5 = *((char **)t3);
    t3 = ((char*)((ng2)));
    t11 = ((char*)((ng0)));
    memset(t13, 0, 8);
    xsi_vlog_unsigned_lshift(t13, 32, t3, 32, t11, 32);
    t12 = ((char*)((ng2)));
    memset(t14, 0, 8);
    xsi_vlog_unsigned_minus(t14, 32, t13, 32, t12, 32);
    t6 = *((unsigned int *)t5);
    t7 = *((unsigned int *)t14);
    t8 = (t6 & t7);
    *((unsigned int *)t17) = t8;
    t15 = (t5 + 4);
    t16 = (t14 + 4);
    t19 = (t17 + 4);
    t9 = *((unsigned int *)t15);
    t10 = *((unsigned int *)t16);
    t29 = (t9 | t10);
    *((unsigned int *)t19) = t29;
    t32 = *((unsigned int *)t19);
    t35 = (t32 != 0);
    if (t35 == 1)
        goto LAB29;

LAB30:
LAB31:    t22 = (t0 + 2872U);
    t23 = *((char **)t22);
    xsi_vlogfile_write(1, 0, 0, ng12, 5, t0, (char)118, t64, 64, (char)118, t4, 32, (char)118, t17, 32, (char)118, t23, 32);
    goto LAB25;

LAB27:    t62 = *((unsigned int *)t14);
    t63 = *((unsigned int *)t17);
    t37 = (t62 - t63);
    t38 = (t37 + 1);
    xsi_vlogvar_wait_assign_value(t19, t20, 0, *((unsigned int *)t17), t38, 0LL);
    goto LAB28;

LAB29:    t36 = *((unsigned int *)t17);
    t39 = *((unsigned int *)t19);
    *((unsigned int *)t17) = (t36 | t39);
    t20 = (t5 + 4);
    t21 = (t14 + 4);
    t40 = *((unsigned int *)t5);
    t41 = (~(t40));
    t42 = *((unsigned int *)t20);
    t43 = (~(t42));
    t44 = *((unsigned int *)t14);
    t45 = (~(t44));
    t46 = *((unsigned int *)t21);
    t47 = (~(t46));
    t30 = (t41 & t43);
    t33 = (t45 & t47);
    t48 = (~(t30));
    t49 = (~(t33));
    t50 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t50 & t48);
    t51 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t51 & t49);
    t52 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t52 & t48);
    t53 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t53 & t49);
    goto LAB31;

LAB34:    t11 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB35;

LAB36:
LAB39:    t15 = (t0 + 2872U);
    t16 = *((char **)t15);
    memset(t14, 0, 8);
    t15 = (t14 + 4);
    t19 = (t16 + 4);
    t47 = *((unsigned int *)t16);
    t48 = (t47 >> 0);
    *((unsigned int *)t14) = t48;
    t49 = *((unsigned int *)t19);
    t50 = (t49 >> 0);
    *((unsigned int *)t15) = t50;
    t51 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t51 & 65535U);
    t52 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t52 & 65535U);
    t20 = (t0 + 3432);
    t21 = (t0 + 3432);
    t22 = (t21 + 72U);
    t23 = *((char **)t22);
    t24 = (t0 + 3432);
    t25 = (t24 + 64U);
    t26 = *((char **)t25);
    t27 = (t0 + 2712U);
    t28 = *((char **)t27);
    memset(t65, 0, 8);
    t27 = (t65 + 4);
    t31 = (t28 + 4);
    t53 = *((unsigned int *)t28);
    t54 = (t53 >> 2);
    *((unsigned int *)t65) = t54;
    t55 = *((unsigned int *)t31);
    t56 = (t55 >> 2);
    *((unsigned int *)t27) = t56;
    t57 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t57 & 16383U);
    t59 = *((unsigned int *)t27);
    *((unsigned int *)t27) = (t59 & 16383U);
    xsi_vlog_generic_convert_array_indices(t17, t18, t23, t26, 2, 1, t65, 14, 2);
    t58 = (t0 + 3432);
    t60 = (t58 + 72U);
    t69 = *((char **)t60);
    t70 = ((char*)((ng0)));
    t71 = ((char*)((ng1)));
    t72 = (t0 + 2712U);
    t73 = *((char **)t72);
    t72 = (t0 + 2672U);
    t75 = (t72 + 72U);
    t76 = *((char **)t75);
    t77 = ((char*)((ng2)));
    xsi_vlog_generic_get_index_select_value(t74, 32, t73, t76, 2, t77, 32, 1);
    memset(t78, 0, 8);
    xsi_vlog_unsigned_multiply(t78, 32, t71, 32, t74, 32);
    memset(t79, 0, 8);
    xsi_vlog_unsigned_add(t79, 32, t70, 32, t78, 32);
    t80 = ((char*)((ng1)));
    xsi_vlog_convert_indexed_partindices(t66, t67, t68, ((int*)(t69)), 2, t79, 32, 2, t80, 32, 1, 0);
    t81 = (t17 + 4);
    t61 = *((unsigned int *)t81);
    t30 = (!(t61));
    t82 = (t18 + 4);
    t62 = *((unsigned int *)t82);
    t33 = (!(t62));
    t34 = (t30 && t33);
    t83 = (t66 + 4);
    t63 = *((unsigned int *)t83);
    t37 = (!(t63));
    t38 = (t34 && t37);
    t84 = (t67 + 4);
    t85 = *((unsigned int *)t84);
    t86 = (!(t85));
    t87 = (t38 && t86);
    t88 = (t68 + 4);
    t89 = *((unsigned int *)t88);
    t90 = (!(t89));
    t91 = (t87 && t90);
    if (t91 == 1)
        goto LAB40;

LAB41:    t2 = xsi_vlog_time(t64, 1000.0000000000000, 1000.0000000000000);
    t3 = (t0 + 1912U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng5)));
    t5 = (t0 + 2712U);
    t11 = *((char **)t5);
    memset(t14, 0, 8);
    t5 = (t14 + 4);
    t12 = (t11 + 4);
    t6 = *((unsigned int *)t11);
    t7 = (t6 >> 2);
    *((unsigned int *)t14) = t7;
    t8 = *((unsigned int *)t12);
    t9 = (t8 >> 2);
    *((unsigned int *)t5) = t9;
    t10 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t10 & 1073741823U);
    t29 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t29 & 1073741823U);
    xsi_vlogtype_concat(t13, 32, 32, 2U, t14, 30, t3, 2);
    t15 = ((char*)((ng2)));
    t16 = ((char*)((ng0)));
    memset(t17, 0, 8);
    xsi_vlog_unsigned_lshift(t17, 32, t15, 32, t16, 32);
    t19 = ((char*)((ng2)));
    memset(t18, 0, 8);
    xsi_vlog_unsigned_minus(t18, 32, t17, 32, t19, 32);
    t32 = *((unsigned int *)t13);
    t35 = *((unsigned int *)t18);
    t36 = (t32 & t35);
    *((unsigned int *)t65) = t36;
    t20 = (t13 + 4);
    t21 = (t18 + 4);
    t22 = (t65 + 4);
    t39 = *((unsigned int *)t20);
    t40 = *((unsigned int *)t21);
    t41 = (t39 | t40);
    *((unsigned int *)t22) = t41;
    t42 = *((unsigned int *)t22);
    t43 = (t42 != 0);
    if (t43 == 1)
        goto LAB42;

LAB43:
LAB44:    t25 = (t0 + 2872U);
    t26 = *((char **)t25);
    t25 = (t0 + 3432);
    t27 = (t25 + 56U);
    t28 = *((char **)t27);
    t31 = (t0 + 3432);
    t58 = (t31 + 72U);
    t60 = *((char **)t58);
    t69 = (t0 + 3432);
    t70 = (t69 + 64U);
    t71 = *((char **)t70);
    t72 = (t0 + 2712U);
    t73 = *((char **)t72);
    memset(t67, 0, 8);
    t72 = (t67 + 4);
    t75 = (t73 + 4);
    t62 = *((unsigned int *)t73);
    t63 = (t62 >> 2);
    *((unsigned int *)t67) = t63;
    t85 = *((unsigned int *)t75);
    t89 = (t85 >> 2);
    *((unsigned int *)t72) = t89;
    t92 = *((unsigned int *)t67);
    *((unsigned int *)t67) = (t92 & 16383U);
    t94 = *((unsigned int *)t72);
    *((unsigned int *)t72) = (t94 & 16383U);
    xsi_vlog_generic_get_array_select_value(t66, 32, t28, t60, t71, 2, 1, t67, 14, 2);
    t76 = (t0 + 5776);
    t77 = (t0 + 848);
    t80 = xsi_create_subprogram_invocation(t76, 0, t0, t77, 0, 0);
    t81 = (t0 + 3912);
    xsi_vlogvar_assign_value(t81, t26, 0, 0, 32);
    t82 = (t0 + 4072);
    xsi_vlogvar_assign_value(t82, t66, 0, 0, 32);

LAB45:    t83 = (t0 + 5872);
    t84 = *((char **)t83);
    t88 = (t84 + 80U);
    t101 = *((char **)t88);
    t102 = (t101 + 272U);
    t103 = *((char **)t102);
    t104 = (t103 + 0U);
    t105 = *((char **)t104);
    t34 = ((int  (*)(char *, char *))t105)(t0, t84);
    if (t34 != 0)
        goto LAB47;

LAB46:    t84 = (t0 + 5872);
    t106 = *((char **)t84);
    t84 = (t0 + 3752);
    t107 = (t84 + 56U);
    t108 = *((char **)t107);
    memcpy(t68, t108, 8);
    t109 = (t0 + 848);
    t110 = (t0 + 5776);
    t111 = 0;
    xsi_delete_subprogram_invocation(t109, t106, t0, t110, t111);
    xsi_vlogfile_write(1, 0, 0, ng12, 5, t0, (char)118, t64, 64, (char)118, t4, 32, (char)118, t65, 32, (char)118, t68, 32);
    goto LAB38;

LAB40:    t92 = *((unsigned int *)t68);
    t93 = (t92 + 0);
    t94 = *((unsigned int *)t18);
    t95 = *((unsigned int *)t67);
    t96 = (t94 + t95);
    t97 = *((unsigned int *)t66);
    t98 = *((unsigned int *)t67);
    t99 = (t97 - t98);
    t100 = (t99 + 1);
    xsi_vlogvar_wait_assign_value(t20, t14, t93, t96, t100, 0LL);
    goto LAB41;

LAB42:    t44 = *((unsigned int *)t65);
    t45 = *((unsigned int *)t22);
    *((unsigned int *)t65) = (t44 | t45);
    t23 = (t13 + 4);
    t24 = (t18 + 4);
    t46 = *((unsigned int *)t13);
    t47 = (~(t46));
    t48 = *((unsigned int *)t23);
    t49 = (~(t48));
    t50 = *((unsigned int *)t18);
    t51 = (~(t50));
    t52 = *((unsigned int *)t24);
    t53 = (~(t52));
    t30 = (t47 & t49);
    t33 = (t51 & t53);
    t54 = (~(t30));
    t55 = (~(t33));
    t56 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t56 & t54);
    t57 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t57 & t55);
    t59 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t59 & t54);
    t61 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t61 & t55);
    goto LAB44;

LAB47:    t83 = (t0 + 5968U);
    *((char **)t83) = &&LAB45;
    goto LAB1;

LAB50:    t11 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB51;

LAB52:
LAB55:    t15 = (t0 + 2872U);
    t16 = *((char **)t15);
    memset(t14, 0, 8);
    t15 = (t14 + 4);
    t19 = (t16 + 4);
    t47 = *((unsigned int *)t16);
    t48 = (t47 >> 0);
    *((unsigned int *)t14) = t48;
    t49 = *((unsigned int *)t19);
    t50 = (t49 >> 0);
    *((unsigned int *)t15) = t50;
    t51 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t51 & 255U);
    t52 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t52 & 255U);
    t20 = (t0 + 3432);
    t21 = (t0 + 3432);
    t22 = (t21 + 72U);
    t23 = *((char **)t22);
    t24 = (t0 + 3432);
    t25 = (t24 + 64U);
    t26 = *((char **)t25);
    t27 = (t0 + 2712U);
    t28 = *((char **)t27);
    memset(t65, 0, 8);
    t27 = (t65 + 4);
    t31 = (t28 + 4);
    t53 = *((unsigned int *)t28);
    t54 = (t53 >> 2);
    *((unsigned int *)t65) = t54;
    t55 = *((unsigned int *)t31);
    t56 = (t55 >> 2);
    *((unsigned int *)t27) = t56;
    t57 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t57 & 16383U);
    t59 = *((unsigned int *)t27);
    *((unsigned int *)t27) = (t59 & 16383U);
    xsi_vlog_generic_convert_array_indices(t17, t18, t23, t26, 2, 1, t65, 14, 2);
    t58 = (t0 + 3432);
    t60 = (t58 + 72U);
    t69 = *((char **)t60);
    t70 = ((char*)((ng3)));
    t71 = ((char*)((ng4)));
    t72 = (t0 + 2712U);
    t73 = *((char **)t72);
    memset(t74, 0, 8);
    t72 = (t74 + 4);
    t75 = (t73 + 4);
    t61 = *((unsigned int *)t73);
    t62 = (t61 >> 0);
    *((unsigned int *)t74) = t62;
    t63 = *((unsigned int *)t75);
    t85 = (t63 >> 0);
    *((unsigned int *)t72) = t85;
    t89 = *((unsigned int *)t74);
    *((unsigned int *)t74) = (t89 & 3U);
    t92 = *((unsigned int *)t72);
    *((unsigned int *)t72) = (t92 & 3U);
    memset(t78, 0, 8);
    xsi_vlog_unsigned_multiply(t78, 32, t71, 32, t74, 32);
    memset(t79, 0, 8);
    xsi_vlog_unsigned_add(t79, 32, t70, 32, t78, 32);
    t76 = ((char*)((ng4)));
    xsi_vlog_convert_indexed_partindices(t66, t67, t68, ((int*)(t69)), 2, t79, 32, 2, t76, 32, 1, 0);
    t77 = (t17 + 4);
    t94 = *((unsigned int *)t77);
    t30 = (!(t94));
    t80 = (t18 + 4);
    t95 = *((unsigned int *)t80);
    t33 = (!(t95));
    t34 = (t30 && t33);
    t81 = (t66 + 4);
    t97 = *((unsigned int *)t81);
    t37 = (!(t97));
    t38 = (t34 && t37);
    t82 = (t67 + 4);
    t98 = *((unsigned int *)t82);
    t86 = (!(t98));
    t87 = (t38 && t86);
    t83 = (t68 + 4);
    t112 = *((unsigned int *)t83);
    t90 = (!(t112));
    t91 = (t87 && t90);
    if (t91 == 1)
        goto LAB56;

LAB57:    t2 = xsi_vlog_time(t64, 1000.0000000000000, 1000.0000000000000);
    t3 = (t0 + 1912U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng5)));
    t5 = (t0 + 2712U);
    t11 = *((char **)t5);
    memset(t14, 0, 8);
    t5 = (t14 + 4);
    t12 = (t11 + 4);
    t6 = *((unsigned int *)t11);
    t7 = (t6 >> 2);
    *((unsigned int *)t14) = t7;
    t8 = *((unsigned int *)t12);
    t9 = (t8 >> 2);
    *((unsigned int *)t5) = t9;
    t10 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t10 & 1073741823U);
    t29 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t29 & 1073741823U);
    xsi_vlogtype_concat(t13, 32, 32, 2U, t14, 30, t3, 2);
    t15 = ((char*)((ng2)));
    t16 = ((char*)((ng0)));
    memset(t17, 0, 8);
    xsi_vlog_unsigned_lshift(t17, 32, t15, 32, t16, 32);
    t19 = ((char*)((ng2)));
    memset(t18, 0, 8);
    xsi_vlog_unsigned_minus(t18, 32, t17, 32, t19, 32);
    t32 = *((unsigned int *)t13);
    t35 = *((unsigned int *)t18);
    t36 = (t32 & t35);
    *((unsigned int *)t65) = t36;
    t20 = (t13 + 4);
    t21 = (t18 + 4);
    t22 = (t65 + 4);
    t39 = *((unsigned int *)t20);
    t40 = *((unsigned int *)t21);
    t41 = (t39 | t40);
    *((unsigned int *)t22) = t41;
    t42 = *((unsigned int *)t22);
    t43 = (t42 != 0);
    if (t43 == 1)
        goto LAB58;

LAB59:
LAB60:    t25 = (t0 + 2872U);
    t26 = *((char **)t25);
    t25 = (t0 + 3432);
    t27 = (t25 + 56U);
    t28 = *((char **)t27);
    t31 = (t0 + 3432);
    t58 = (t31 + 72U);
    t60 = *((char **)t58);
    t69 = (t0 + 3432);
    t70 = (t69 + 64U);
    t71 = *((char **)t70);
    t72 = (t0 + 2712U);
    t73 = *((char **)t72);
    memset(t67, 0, 8);
    t72 = (t67 + 4);
    t75 = (t73 + 4);
    t62 = *((unsigned int *)t73);
    t63 = (t62 >> 2);
    *((unsigned int *)t67) = t63;
    t85 = *((unsigned int *)t75);
    t89 = (t85 >> 2);
    *((unsigned int *)t72) = t89;
    t92 = *((unsigned int *)t67);
    *((unsigned int *)t67) = (t92 & 16383U);
    t94 = *((unsigned int *)t72);
    *((unsigned int *)t72) = (t94 & 16383U);
    xsi_vlog_generic_get_array_select_value(t66, 32, t28, t60, t71, 2, 1, t67, 14, 2);
    t76 = (t0 + 5776);
    t77 = (t0 + 1280);
    t80 = xsi_create_subprogram_invocation(t76, 0, t0, t77, 0, 0);
    t81 = (t0 + 4392);
    xsi_vlogvar_assign_value(t81, t26, 0, 0, 32);
    t82 = (t0 + 4552);
    xsi_vlogvar_assign_value(t82, t66, 0, 0, 32);

LAB61:    t83 = (t0 + 5872);
    t84 = *((char **)t83);
    t88 = (t84 + 80U);
    t101 = *((char **)t88);
    t102 = (t101 + 272U);
    t103 = *((char **)t102);
    t104 = (t103 + 0U);
    t105 = *((char **)t104);
    t34 = ((int  (*)(char *, char *))t105)(t0, t84);
    if (t34 != 0)
        goto LAB63;

LAB62:    t84 = (t0 + 5872);
    t106 = *((char **)t84);
    t84 = (t0 + 4232);
    t107 = (t84 + 56U);
    t108 = *((char **)t107);
    memcpy(t68, t108, 8);
    t109 = (t0 + 1280);
    t110 = (t0 + 5776);
    t111 = 0;
    xsi_delete_subprogram_invocation(t109, t106, t0, t110, t111);
    xsi_vlogfile_write(1, 0, 0, ng12, 5, t0, (char)118, t64, 64, (char)118, t4, 32, (char)118, t65, 32, (char)118, t68, 32);
    goto LAB54;

LAB56:    t113 = *((unsigned int *)t68);
    t93 = (t113 + 0);
    t114 = *((unsigned int *)t18);
    t115 = *((unsigned int *)t67);
    t96 = (t114 + t115);
    t116 = *((unsigned int *)t66);
    t117 = *((unsigned int *)t67);
    t99 = (t116 - t117);
    t100 = (t99 + 1);
    xsi_vlogvar_wait_assign_value(t20, t14, t93, t96, t100, 0LL);
    goto LAB57;

LAB58:    t44 = *((unsigned int *)t65);
    t45 = *((unsigned int *)t22);
    *((unsigned int *)t65) = (t44 | t45);
    t23 = (t13 + 4);
    t24 = (t18 + 4);
    t46 = *((unsigned int *)t13);
    t47 = (~(t46));
    t48 = *((unsigned int *)t23);
    t49 = (~(t48));
    t50 = *((unsigned int *)t18);
    t51 = (~(t50));
    t52 = *((unsigned int *)t24);
    t53 = (~(t52));
    t30 = (t47 & t49);
    t33 = (t51 & t53);
    t54 = (~(t30));
    t55 = (~(t33));
    t56 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t56 & t54);
    t57 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t57 & t55);
    t59 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t59 & t54);
    t61 = *((unsigned int *)t65);
    *((unsigned int *)t65) = (t61 & t55);
    goto LAB60;

LAB63:    t83 = (t0 + 5968U);
    *((char **)t83) = &&LAB61;
    goto LAB1;

}


extern void work_m_00000000003763996657_0495241494_init()
{
	static char *pe[] = {(void *)Cont_25_0,(void *)Initial_34_1,(void *)Always_56_2};
	static char *se[] = {(void *)sp_F_H_OUT,(void *)sp_F_B_OUT};
	xsi_register_didat("work_m_00000000003763996657_0495241494", "isim/mips.exe.sim/work/m_00000000003763996657_0495241494.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
