import random
import os
file = open("mipscode.asm", "w")
codeline = 0
jal = False
# generate mipscode
while codeline <= 400:
    instr = random.randint(0, 37)
    op1 = random.randint(0, 27)
    op2 = random.randint(0, 27)
    op3 = random.randint(0, 27)
    imm16 = random.randint(0, 65535)
    branchnum = imm16 / 4 * 4
    codeline += 1
    file.write('label' + str(codeline) + ':')
    if 0 <= instr <= 5:
        file.write('addu $' + str(op1) + ',$' + str(op2) + ',$' + str(op3) + '\n')
    elif 6 <= instr <= 10:
        file.write('subu $' + str(op1) + ',$' + str(op2) + ',$' + str(op3) + '\n')
    elif 11 <= instr <= 20:
        file.write('ori $' + str(op1) + ',$' + str(op2) + ',' + str(imm16) + '\n')
    elif 21 <= instr <= 25:
        file.write('lui $' + str(op1) + ',' + str(random.randint(0, 32767)) + '\n')
    elif 26 <= instr <= 30:
        temp = random.randint(0, 1024) * 4
        codeline += 1
        file.write('lw $' + str(op1) + ',' + str(temp) + '($0)\n')
        file.write('label' + str(codeline) + ':')
        file.write('sw $' + str(op1) + ',' + str(temp) + '($0)\n')

    elif instr == 31:
        file.write('jal ' + 'label' + str(random.randint(1, 400)) + '\n')
        jal = True
    elif instr == 32:
        if jal:
            file.write('jr $31' + '\n')
            jal = False
        else:
            file.write('ori $' + str(op1) + ',$' + str(op2) + ',' + str(imm16) + '\n')
    elif instr == 33:
        file.write('nop' + '\n')
    elif instr == 34 or instr == 35:
        file.write('beq $' + str(op1) + ',$' + str(op1) + ',label' + str(random.randint(1, 400)) + '\n')
    elif instr == 36 or instr == 37:
        file.write('beq $' + str(op1) + ',$' + str(op2) + ',label' + str(random.randint(1, 400)) + '\n')



