/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/faq/Desktop/log/p6/endlww/MD.v";
static unsigned int ng1[] = {0U, 0U};
static int ng2[] = {5, 0};
static unsigned int ng3[] = {1U, 0U};
static unsigned int ng4[] = {2U, 0U};
static int ng5[] = {0, 0};
static int ng6[] = {10, 0};
static unsigned int ng7[] = {3U, 0U};
static int ng8[] = {1, 0};



static void Initial_35_0(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(35, ng0);

LAB2:    xsi_set_current_line(36, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 2728);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 32, 0LL);
    xsi_set_current_line(37, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 32, 0LL);
    xsi_set_current_line(38, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 32, 0LL);

LAB1:    return;
}

static void Always_40_1(char *t0)
{
    char t14[16];
    char t15[16];
    char t17[16];
    char t19[8];
    char t20[8];
    char t21[8];
    char t44[8];
    char t49[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    int t13;
    char *t16;
    char *t18;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    char *t45;
    char *t46;
    char *t48;

LAB0:    t1 = (t0 + 4216U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(40, ng0);
    t2 = (t0 + 4784);
    *((int *)t2) = 1;
    t3 = (t0 + 4248);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(40, ng0);

LAB5:    xsi_set_current_line(41, ng0);
    t4 = (t0 + 1048U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(46, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB10;

LAB11:    xsi_set_current_line(68, ng0);
    t2 = (t0 + 2008U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB96;

LAB97:    xsi_set_current_line(71, ng0);
    t2 = (t0 + 2168U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB100;

LAB101:    xsi_set_current_line(74, ng0);
    t2 = (t0 + 3048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t11 = (t4 + 4);
    t6 = *((unsigned int *)t11);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB104;

LAB105:
LAB106:
LAB102:
LAB98:
LAB12:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(41, ng0);

LAB9:    xsi_set_current_line(42, ng0);
    t11 = ((char*)((ng1)));
    t12 = (t0 + 2728);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 32, 0LL);
    xsi_set_current_line(43, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 32, 0LL);
    xsi_set_current_line(44, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 32, 0LL);
    goto LAB8;

LAB10:    xsi_set_current_line(46, ng0);

LAB13:    xsi_set_current_line(47, ng0);
    t4 = (t0 + 1848U);
    t5 = *((char **)t4);

LAB14:    t4 = ((char*)((ng1)));
    t13 = xsi_vlog_unsigned_case_compare(t5, 2, t4, 2);
    if (t13 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng3)));
    t13 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t13 == 1)
        goto LAB17;

LAB18:    t2 = ((char*)((ng4)));
    t13 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t13 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng7)));
    t13 = xsi_vlog_unsigned_case_compare(t5, 2, t2, 2);
    if (t13 == 1)
        goto LAB21;

LAB22:
LAB23:    goto LAB12;

LAB15:    xsi_set_current_line(48, ng0);

LAB24:    xsi_set_current_line(49, ng0);
    t11 = (t0 + 1528U);
    t12 = *((char **)t11);
    xsi_vlogtype_sign_extend(t14, 64, t12, 32);
    t11 = (t0 + 1688U);
    t16 = *((char **)t11);
    xsi_vlogtype_sign_extend(t15, 64, t16, 32);
    xsi_vlog_signed_multiply(t17, 64, t14, 64, t15, 64);
    t11 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t11, t17, 0, 0, 32, 0LL);
    t18 = (t0 + 2728);
    xsi_vlogvar_wait_assign_value(t18, t17, 32, 0, 32, 0LL);
    xsi_set_current_line(50, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 32, 0LL);
    goto LAB23;

LAB17:    xsi_set_current_line(52, ng0);

LAB25:    xsi_set_current_line(53, ng0);
    t3 = (t0 + 1528U);
    t4 = *((char **)t3);
    t3 = (t0 + 1688U);
    t11 = *((char **)t3);
    xsi_vlog_unsigned_multiply(t14, 64, t4, 32, t11, 32);
    t3 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t3, t14, 0, 0, 32, 0LL);
    t12 = (t0 + 2728);
    xsi_vlogvar_wait_assign_value(t12, t14, 32, 0, 32, 0LL);
    xsi_set_current_line(54, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 32, 0LL);
    goto LAB23;

LAB19:    xsi_set_current_line(56, ng0);

LAB26:    xsi_set_current_line(57, ng0);
    t3 = (t0 + 1688U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng5)));
    memset(t21, 0, 8);
    t11 = (t4 + 4);
    t12 = (t3 + 4);
    t6 = *((unsigned int *)t4);
    t7 = *((unsigned int *)t3);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t11);
    t10 = *((unsigned int *)t12);
    t22 = (t9 ^ t10);
    t23 = (t8 | t22);
    t24 = *((unsigned int *)t11);
    t25 = *((unsigned int *)t12);
    t26 = (t24 | t25);
    t27 = (~(t26));
    t28 = (t23 & t27);
    if (t28 != 0)
        goto LAB30;

LAB27:    if (t26 != 0)
        goto LAB29;

LAB28:    *((unsigned int *)t21) = 1;

LAB30:    memset(t20, 0, 8);
    t18 = (t21 + 4);
    t29 = *((unsigned int *)t18);
    t30 = (~(t29));
    t31 = *((unsigned int *)t21);
    t32 = (t31 & t30);
    t33 = (t32 & 1U);
    if (t33 != 0)
        goto LAB31;

LAB32:    if (*((unsigned int *)t18) != 0)
        goto LAB33;

LAB34:    t35 = (t20 + 4);
    t36 = *((unsigned int *)t20);
    t37 = *((unsigned int *)t35);
    t38 = (t36 || t37);
    if (t38 > 0)
        goto LAB35;

LAB36:    t40 = *((unsigned int *)t20);
    t41 = (~(t40));
    t42 = *((unsigned int *)t35);
    t43 = (t41 || t42);
    if (t43 > 0)
        goto LAB37;

LAB38:    if (*((unsigned int *)t35) > 0)
        goto LAB39;

LAB40:    if (*((unsigned int *)t20) > 0)
        goto LAB41;

LAB42:    memcpy(t19, t49, 8);

LAB43:    t45 = (t0 + 2728);
    xsi_vlogvar_wait_assign_value(t45, t19, 0, 0, 32, 0LL);
    xsi_set_current_line(58, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng5)));
    memset(t21, 0, 8);
    t4 = (t3 + 4);
    t11 = (t2 + 4);
    t6 = *((unsigned int *)t3);
    t7 = *((unsigned int *)t2);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t11);
    t22 = (t9 ^ t10);
    t23 = (t8 | t22);
    t24 = *((unsigned int *)t4);
    t25 = *((unsigned int *)t11);
    t26 = (t24 | t25);
    t27 = (~(t26));
    t28 = (t23 & t27);
    if (t28 != 0)
        goto LAB47;

LAB44:    if (t26 != 0)
        goto LAB46;

LAB45:    *((unsigned int *)t21) = 1;

LAB47:    memset(t20, 0, 8);
    t16 = (t21 + 4);
    t29 = *((unsigned int *)t16);
    t30 = (~(t29));
    t31 = *((unsigned int *)t21);
    t32 = (t31 & t30);
    t33 = (t32 & 1U);
    if (t33 != 0)
        goto LAB48;

LAB49:    if (*((unsigned int *)t16) != 0)
        goto LAB50;

LAB51:    t34 = (t20 + 4);
    t36 = *((unsigned int *)t20);
    t37 = *((unsigned int *)t34);
    t38 = (t36 || t37);
    if (t38 > 0)
        goto LAB52;

LAB53:    t40 = *((unsigned int *)t20);
    t41 = (~(t40));
    t42 = *((unsigned int *)t34);
    t43 = (t41 || t42);
    if (t43 > 0)
        goto LAB54;

LAB55:    if (*((unsigned int *)t34) > 0)
        goto LAB56;

LAB57:    if (*((unsigned int *)t20) > 0)
        goto LAB58;

LAB59:    memcpy(t19, t49, 8);

LAB60:    t39 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t39, t19, 0, 0, 32, 0LL);
    xsi_set_current_line(59, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 32, 0LL);
    goto LAB23;

LAB21:    xsi_set_current_line(61, ng0);

LAB61:    xsi_set_current_line(62, ng0);
    t3 = (t0 + 1688U);
    t4 = *((char **)t3);
    t3 = ((char*)((ng5)));
    memset(t21, 0, 8);
    t11 = (t4 + 4);
    t12 = (t3 + 4);
    t6 = *((unsigned int *)t4);
    t7 = *((unsigned int *)t3);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t11);
    t10 = *((unsigned int *)t12);
    t22 = (t9 ^ t10);
    t23 = (t8 | t22);
    t24 = *((unsigned int *)t11);
    t25 = *((unsigned int *)t12);
    t26 = (t24 | t25);
    t27 = (~(t26));
    t28 = (t23 & t27);
    if (t28 != 0)
        goto LAB65;

LAB62:    if (t26 != 0)
        goto LAB64;

LAB63:    *((unsigned int *)t21) = 1;

LAB65:    memset(t20, 0, 8);
    t18 = (t21 + 4);
    t29 = *((unsigned int *)t18);
    t30 = (~(t29));
    t31 = *((unsigned int *)t21);
    t32 = (t31 & t30);
    t33 = (t32 & 1U);
    if (t33 != 0)
        goto LAB66;

LAB67:    if (*((unsigned int *)t18) != 0)
        goto LAB68;

LAB69:    t35 = (t20 + 4);
    t36 = *((unsigned int *)t20);
    t37 = *((unsigned int *)t35);
    t38 = (t36 || t37);
    if (t38 > 0)
        goto LAB70;

LAB71:    t40 = *((unsigned int *)t20);
    t41 = (~(t40));
    t42 = *((unsigned int *)t35);
    t43 = (t41 || t42);
    if (t43 > 0)
        goto LAB72;

LAB73:    if (*((unsigned int *)t35) > 0)
        goto LAB74;

LAB75:    if (*((unsigned int *)t20) > 0)
        goto LAB76;

LAB77:    memcpy(t19, t44, 8);

LAB78:    t45 = (t0 + 2728);
    xsi_vlogvar_wait_assign_value(t45, t19, 0, 0, 32, 0LL);
    xsi_set_current_line(63, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng5)));
    memset(t21, 0, 8);
    t4 = (t3 + 4);
    t11 = (t2 + 4);
    t6 = *((unsigned int *)t3);
    t7 = *((unsigned int *)t2);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t11);
    t22 = (t9 ^ t10);
    t23 = (t8 | t22);
    t24 = *((unsigned int *)t4);
    t25 = *((unsigned int *)t11);
    t26 = (t24 | t25);
    t27 = (~(t26));
    t28 = (t23 & t27);
    if (t28 != 0)
        goto LAB82;

LAB79:    if (t26 != 0)
        goto LAB81;

LAB80:    *((unsigned int *)t21) = 1;

LAB82:    memset(t20, 0, 8);
    t16 = (t21 + 4);
    t29 = *((unsigned int *)t16);
    t30 = (~(t29));
    t31 = *((unsigned int *)t21);
    t32 = (t31 & t30);
    t33 = (t32 & 1U);
    if (t33 != 0)
        goto LAB83;

LAB84:    if (*((unsigned int *)t16) != 0)
        goto LAB85;

LAB86:    t34 = (t20 + 4);
    t36 = *((unsigned int *)t20);
    t37 = *((unsigned int *)t34);
    t38 = (t36 || t37);
    if (t38 > 0)
        goto LAB87;

LAB88:    t40 = *((unsigned int *)t20);
    t41 = (~(t40));
    t42 = *((unsigned int *)t34);
    t43 = (t41 || t42);
    if (t43 > 0)
        goto LAB89;

LAB90:    if (*((unsigned int *)t34) > 0)
        goto LAB91;

LAB92:    if (*((unsigned int *)t20) > 0)
        goto LAB93;

LAB94:    memcpy(t19, t44, 8);

LAB95:    t39 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t39, t19, 0, 0, 32, 0LL);
    xsi_set_current_line(64, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 32, 0LL);
    goto LAB23;

LAB29:    t16 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t16) = 1;
    goto LAB30;

LAB31:    *((unsigned int *)t20) = 1;
    goto LAB34;

LAB33:    t34 = (t20 + 4);
    *((unsigned int *)t20) = 1;
    *((unsigned int *)t34) = 1;
    goto LAB34;

LAB35:    t39 = ((char*)((ng5)));
    goto LAB36;

LAB37:    t45 = (t0 + 1528U);
    t46 = *((char **)t45);
    t45 = (t0 + 1688U);
    t48 = *((char **)t45);
    memset(t49, 0, 8);
    xsi_vlog_signed_mod(t49, 32, t46, 32, t48, 32);
    goto LAB38;

LAB39:    xsi_vlog_unsigned_bit_combine(t19, 32, t39, 32, t49, 32);
    goto LAB43;

LAB41:    memcpy(t19, t39, 8);
    goto LAB43;

LAB46:    t12 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t12) = 1;
    goto LAB47;

LAB48:    *((unsigned int *)t20) = 1;
    goto LAB51;

LAB50:    t18 = (t20 + 4);
    *((unsigned int *)t20) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB51;

LAB52:    t35 = ((char*)((ng5)));
    goto LAB53;

LAB54:    t39 = (t0 + 1528U);
    t45 = *((char **)t39);
    t39 = (t0 + 1688U);
    t46 = *((char **)t39);
    memset(t49, 0, 8);
    xsi_vlog_signed_divide(t49, 32, t45, 32, t46, 32);
    goto LAB55;

LAB56:    xsi_vlog_unsigned_bit_combine(t19, 32, t35, 32, t49, 32);
    goto LAB60;

LAB58:    memcpy(t19, t35, 8);
    goto LAB60;

LAB64:    t16 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t16) = 1;
    goto LAB65;

LAB66:    *((unsigned int *)t20) = 1;
    goto LAB69;

LAB68:    t34 = (t20 + 4);
    *((unsigned int *)t20) = 1;
    *((unsigned int *)t34) = 1;
    goto LAB69;

LAB70:    t39 = ((char*)((ng5)));
    goto LAB71;

LAB72:    t45 = (t0 + 1528U);
    t46 = *((char **)t45);
    t45 = (t0 + 1688U);
    t48 = *((char **)t45);
    memset(t44, 0, 8);
    xsi_vlog_unsigned_mod(t44, 32, t46, 32, t48, 32);
    goto LAB73;

LAB74:    xsi_vlog_unsigned_bit_combine(t19, 32, t39, 32, t44, 32);
    goto LAB78;

LAB76:    memcpy(t19, t39, 8);
    goto LAB78;

LAB81:    t12 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t12) = 1;
    goto LAB82;

LAB83:    *((unsigned int *)t20) = 1;
    goto LAB86;

LAB85:    t18 = (t20 + 4);
    *((unsigned int *)t20) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB86;

LAB87:    t35 = ((char*)((ng5)));
    goto LAB88;

LAB89:    t39 = (t0 + 1528U);
    t45 = *((char **)t39);
    t39 = (t0 + 1688U);
    t46 = *((char **)t39);
    memset(t44, 0, 8);
    xsi_vlog_unsigned_divide(t44, 32, t45, 32, t46, 32);
    goto LAB90;

LAB91:    xsi_vlog_unsigned_bit_combine(t19, 32, t35, 32, t44, 32);
    goto LAB95;

LAB93:    memcpy(t19, t35, 8);
    goto LAB95;

LAB96:    xsi_set_current_line(68, ng0);

LAB99:    xsi_set_current_line(69, ng0);
    t4 = (t0 + 1528U);
    t11 = *((char **)t4);
    t4 = (t0 + 2728);
    xsi_vlogvar_wait_assign_value(t4, t11, 0, 0, 32, 0LL);
    goto LAB98;

LAB100:    xsi_set_current_line(71, ng0);

LAB103:    xsi_set_current_line(72, ng0);
    t4 = (t0 + 1528U);
    t11 = *((char **)t4);
    t4 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t4, t11, 0, 0, 32, 0LL);
    goto LAB102;

LAB104:    xsi_set_current_line(74, ng0);

LAB107:    xsi_set_current_line(75, ng0);
    t12 = (t0 + 3048);
    t16 = (t12 + 56U);
    t18 = *((char **)t16);
    t34 = ((char*)((ng8)));
    memset(t19, 0, 8);
    xsi_vlog_unsigned_minus(t19, 32, t18, 32, t34, 32);
    t35 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t35, t19, 0, 0, 32, 0LL);
    goto LAB106;

}

static void Cont_78_2(char *t0)
{
    char t6[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;

LAB0:    t1 = (t0 + 4464U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(78, ng0);
    t2 = (t0 + 3048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng5)));
    memset(t6, 0, 8);
    t7 = (t4 + 4);
    t8 = (t5 + 4);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB5;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB7:    t22 = (t0 + 4880);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    memset(t26, 0, 8);
    t27 = 1U;
    t28 = t27;
    t29 = (t6 + 4);
    t30 = *((unsigned int *)t6);
    t27 = (t27 & t30);
    t31 = *((unsigned int *)t29);
    t28 = (t28 & t31);
    t32 = (t26 + 4);
    t33 = *((unsigned int *)t26);
    *((unsigned int *)t26) = (t33 | t27);
    t34 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t34 | t28);
    xsi_driver_vfirst_trans(t22, 0, 0);
    t35 = (t0 + 4800);
    *((int *)t35) = 1;

LAB1:    return;
LAB5:    *((unsigned int *)t6) = 1;
    goto LAB7;

LAB6:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

}


extern void work_m_00000000000865775983_0105961027_init()
{
	static char *pe[] = {(void *)Initial_35_0,(void *)Always_40_1,(void *)Cont_78_2};
	xsi_register_didat("work_m_00000000000865775983_0105961027", "isim/mips_tb_isim_beh.exe.sim/work/m_00000000000865775983_0105961027.didat");
	xsi_register_executes(pe);
}
